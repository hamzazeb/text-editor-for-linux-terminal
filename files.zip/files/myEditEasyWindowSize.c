/*** includes ****/
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <errno.h>
#include <sys/ioctl.h> 
#include <unistd.h>


/**** defines ****/

# define CTRL_KEY(k) ((k) & 0x1f) // will AND the key we entered(along with Ctrl) with 0x1f(00011111).

/*** data ****/

struct editorConfig
{
	int screenrows;
	int screencols;
	struct termios orig_termios;
};

struct editorConfig E;

/*** terminal ****/

void die(const char *s)
{
	write(STDOUT_FILENO, "\x1b[2J", 4);
	write(STDOUT_FILENO, "\x1b[H", 3);
	
	perror(s);
	exit(1);
}

void disableRawMode()
{
	if( tcsetattr(STDIN_FILENO, TCSAFLUSH, &E.orig_termios) == -1)
		die("Error in tcsetattr");
}

void enableRawMode()
{	
	if( tcgetattr(STDIN_FILENO, &E.orig_termios) == -1)
		die("Error in tcgetattr");
	atexit(disableRawMode);		// when returning from main or run exit() in main then this will execute

	struct termios raw = E.orig_termios;
	
	raw.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON); //input flag, ICRNL used to fix Ctrl-M, IXON used to disable Ctlr-S and Ctrl-Q
	raw.c_oflag &= ~(OPOST);	//output flag, here I assume POST stands for post-processing-of-output
	raw.c_cflag |= (CS8);		//control flag, it sets character size CS to 8 bits each byte
	raw.c_lflag &= ~(ECHO | ICANON | IEXTEN | ISIG);	//local flag, ECHO property is used to print out at terminal, ICANON is a flag used to read byte by byte, ISIG is a flag used to diable Ctrl-C and Ctrl-Z, IEXTEN flag is used to fix Ctrl-V and Ctrl-O.
	raw.c_cc[VMIN] = 0;	// cc stands for control character, min num of bytes of input needed before read can return.
	raw.c_cc[VTIME] = 1;	// max amount of time to wait before read returns. It is 1/10 of second.
	if( tcsetattr(STDIN_FILENO ,TCSAFLUSH, &raw) == -1)
		die("Error in tcsetattr");
}


char editorReadKey()
{
	int nread;
	char c;
	while ((nread = read(STDIN_FILENO, &c, 1)) != 1 )	// here it will wait until it read 1 character
	{
		if (nread == -1 && errno != EAGAIN)
		die("Error in read");
	}
	return c;
}

int getWindowSize(int *rows, int *cols)				// used to get the size of window rows and cols of window
{
	struct winsize ws;
	
	if(ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == -1 || ws.ws_col == 0 )
	{
		return -1;
	}
	else
	{
		*cols = ws.ws_col;
		*rows = ws.ws_row;
		return 0;
	}
}

/**** output ****/

void editorDrawRows()
{
	int y;
	for ( y=0; y<E.screenrows; y++)			// screenrows we get using getWindowSize() below
	{
		write(STDOUT_FILENO, "~\r\n", 3);	// will draw ~ at start of each row
	}
}

void editorRefreshScreen()
{
	write(STDOUT_FILENO, "\x1b[2J", 4); 	//write out the escape scequence\x1b to the editor, escape scequence instruct the terminal to do various tasks like text coloring, cursor position etc // here 2J means clear the whole screen without moving our cursor
	write(STDOUT_FILENO, "\x1b[H", 3);	// setting our cursor to the left top of our editor
	
	editorDrawRows();
	
	write(STDOUT_FILENO, "\x1b[H", 3);	// reposition our cursor to top left
}

/**** input ****/

void editorProcessKeypress()
{
	char c = editorReadKey();

	switch (c)
	{
		case CTRL_KEY('q'):
		 write(STDOUT_FILENO, "\x1b[2J", 4);		// clear whole screen
		 write(STDOUT_FILENO, "\x1b[H", 3);		// reposition our cursor to top left
		 exit(0);
		 break;
	}
}

/**** init ****/

void initEditor()
{
	if (getWindowSize(&E.screenrows, &E.screencols) == -1 )
		die("Error in getWindowSize");
}
	
int main()
{
	enableRawMode();
	initEditor();

	while(1)
	{
	editorRefreshScreen();
	editorProcessKeypress();
	}

	return 0;
}
